
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 1,
    category: "Signature Tteokbokki",
    name: "Classic Spicy Tteokbokki",
    tagline: "The original fiery flavor.",
    price: "$12.99",
    imageUrl: "https://picsum.photos/seed/tokbokki1/800/600",
  },
  {
    id: 2,
    category: "Modern Twist",
    name: "Rosé Tteokbokki",
    tagline: "Creamy, dreamy, and delicious.",
    price: "$14.99",
    imageUrl: "https://picsum.photos/seed/tokbokki2/800/600",
  },
  {
    id: 3,
    category: "Cheesy Delight",
    name: "Cheese Tteokbokki",
    tagline: "A melted cheese paradise.",
    price: "$15.99",
    imageUrl: "https://picsum.photos/seed/tokbokki3/800/600",
  },
  {
    id: 4,
    category: "Perfect Pairing",
    name: "Gimbap Rolls",
    tagline: "The perfect sidekick.",
    price: "$9.99",
    imageUrl: "https://picsum.photos/seed/gimbap/800/600",
  },
  {
    id: 5,
    category: "Noodle Lovers",
    name: "Spicy Ramyeon",
    tagline: "Instant joy in a bowl.",
    price: "$8.99",
    imageUrl: "https://picsum.photos/seed/ramyeon/800/600",
  },
  {
    id: 6,
    category: "Crispy & Savory",
    name: "Korean Fried Chicken",
    tagline: "Extra crispy, perfectly seasoned.",
    price: "$18.99",
    imageUrl: "https://picsum.photos/seed/kfc/800/600",
  },
];

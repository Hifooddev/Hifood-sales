
import React from 'react';
import Header from './components/Header';
import ProductGrid from './components/ProductGrid';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white font-sans text-zinc-800">
      <Header />
      <main className="pt-20">
        <div className="text-center px-6 py-16 md:py-24">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-zinc-900">
            Store. <span className="text-zinc-500">The best way to buy the food you love.</span>
          </h1>
        </div>
        <ProductGrid />
      </main>
      <Footer />
    </div>
  );
};

export default App;

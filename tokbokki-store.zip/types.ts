
export interface Product {
  id: number;
  category: string;
  name: string;
  tagline: string;
  price: string;
  imageUrl: string;
}
